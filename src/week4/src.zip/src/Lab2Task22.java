public class Lab2Task22 {
    public static void main(String[] args) {
        int x = 1;
        int a = 3;
        switch (a) {
            case 1:
                x = x + 5;
            case 2:
                x = x + 10;
            case 3 :
                x = x+16;
            case 4:x=x+34;

        }
    }
}
