public class week5task3 {
    public static void main(String[] args) {
        System.out.println(Math.ceil(2.1));
        System.out.println(Math.ceil(2.0));
        System.out.println(Math.ceil(-2.0));
        System.out.println(Math.ceil(-2.1));
        System.out.println(Math.floor(2.1));
        System.out.println(Math.floor(2.0));
        System.out.println(Math.floor(-2.0));
        System.out.println(Math.floor(-2.1));
        System.out.println(Math.rint(2.1));
        System.out.println(Math.rint(-2.0));
        System.out.println(Math.rint(-2.1));
        System.out.println(Math.rint(2.5));
        System.out.println(Math.rint(3.5));
        System.out.println(Math.rint(-2.5));
        System.out.println(Math.round(2.6f));
        System.out.println(Math.round(2.0));
        System.out.println(Math.round(-2.0f));
        System.out.println(Math.round(-2.6));
        System.out.println(Math.round(-2.4));

    }
}
