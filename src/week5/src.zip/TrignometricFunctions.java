public class TrignometricFunctions {
public static void main(String[] args) {
         System.out.println("The value of sin(PI/2): " + Math.sin(Math.PI / 2));
         System.out.println("The value of cos(PI/2): "+ Math.cos(Math.PI / 2));
         System.out.println("The value of tan(PI):' "+ Math.tan(0));
         System.out.println("The value of asin(0.5): " + Math.asin(0.5));
        System.out.println("The value of acos(0.5): " + Math.acos(0.5));
        System.out.println("The value of atan(1): "+ Math.atan(1));
         }
 }
