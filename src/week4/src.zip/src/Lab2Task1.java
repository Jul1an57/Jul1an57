public class Lab2Task1 {
    public static void main(String[] args) {
        double miles = 100;
        double KILOMETERS_PER_MILE = 1.609;
        double km;
        km = miles*KILOMETERS_PER_MILE;
        System.out.println(km);
    }
}
