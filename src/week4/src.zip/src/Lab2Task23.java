public class Lab2Task23 {
    public static void main(String[] args) {
        int num1 = 5;
        int num2 = 8;
        int max = (num1 > num2) ? num1 : num2;
    }
}
