public class GetCharFromString{
    public static void main(String[] args){
        String message = "Welcome to Java";
        System.out.println("The first character in message is" + message.charAt(0));
    }
}