public class Lab2Task16 {
    public static void main(String[] args) {

    }
}
